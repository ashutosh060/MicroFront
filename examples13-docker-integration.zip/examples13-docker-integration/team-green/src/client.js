/* globals window */
import GreenRecos from './green-recos/custom-element';

window.customElements.define('green-recos', GreenRecos);
